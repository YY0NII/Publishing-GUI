﻿//******************************************************
// File: Publisher.cs
//
// Purpose: Contains member variables, properties, and 
// methods for the Publisher class
// 
// Written By: Jonathon Carrera
//
// Compiler: Visual Studio 2019
//
//******************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Publishing_Solution
{
    [DataContract]
    public class Publisher
    {
        #region Publisher Member Variables
        [DataMember(Name = "name")]
        public string Name { get; set; }

        [DataMember(Name = "books")]
        public List<Book> Books { get; set; }
        #endregion

        #region Publisher Methods
        //****************************************************
        // Method: Publisher()
        //
        // Purpose: To construct a default Publisher Object.
        // Sets the values of each member variable to a default
        // value.
        //**************************************************** 
        public Publisher()
        {
            Name = "";
            // Visual Studio taught me this
            Books = new List<Book>();
        }

        //****************************************************
        // Method: FindBook()
        //
        // Purpose: Uses a LINQ query to find the book with a
        // specified title. If it doens't find it the method
        // returns null
        //****************************************************
        public Book FindBook(string title)
        {
            IEnumerable<Book> target =
                (from b in Books
                 where b.Title.Equals(title)
                 select b);

            foreach (Book b in target)
            {
                // If at any point we find a book with a matching
                // title
                if (b.Title == title)
                {
                    // Return it
                    return b;
                }
            }

            // Otherwise we didn't find it so return null
            return null;
        }

        //****************************************************
        // Method: FindAllBooks()
        //
        // Purpose: Search through a collection of books and 
        // return a list of books that have the specified 
        // author attached.
        //****************************************************
        public List<Book> FindAllBooks(string first, string last)
        {
            // List to hold the results of the search
            List<Book> results = new List<Book>();

            // Loops through all the books in the list
            foreach (Book b in Books)
            {
                // Loops through the list of authors attached 
                // to each book
                foreach (Author a in b.Authors)
                {
                    // If both conditions are met 
                    if (a.First == first && a.Last == last)
                    {
                        // add it to the results list
                        results.Add(b);
                    }
                }
            }

            return results;
        }

        public override string ToString()
        {
            string publishedBooks = null;

            foreach (Book b in Books)
            {
                publishedBooks += b + "\n";
            }
            return "Producer: " + Name + "\nBook(s): " + publishedBooks + "\n";
        }
        #endregion
    }
}
