﻿//******************************************************
// File: Book.cs
//
// Purpose: Contains member variables, properties, and 
// methods for the Book class
// 
// Written By: Jonathon Carrera
//
// Compiler: Visual Studio 2019
//
//****************************************************** 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Publishing_Solution
{
    [DataContract]
    public class Book
    {
        #region Book Member Variables
        private string title;
        private List<Author> authors;
        private double price;
        #endregion

        #region Book Methods
        //****************************************************
        // Method: Book
        //
        // Purpose: To construct a default Book Object.
        //****************************************************
        public Book()
        {
            title = "How to...";
            // Visual studio taught me this
            authors = new List<Author>();
            price = 1.00;
        }

        #region Book Properties
        [DataMember(Name = "title")]
        //****************************************************
        // Method: Title
        //
        // Purpose: To return or set the value representing the
        // a Books title.
        //****************************************************
        public string Title
        {
            get
            {
                return title;
            }

            set
            {
                title = value;
            }
        }

        [DataMember(Name = "authors")]
        //****************************************************
        // Method: Authors
        //
        // Purpose: To return or set a list containing the 
        // value representing the Book's Authors.
        //****************************************************
        public List<Author> Authors
        {
            get
            {
                return authors;
            }

            set
            {
                authors = value;
            }
        }

        [DataMember(Name = "price")]
        //****************************************************
        // Method: Price
        //
        // Purpose: To return or set the value representing the
        // a Books Price.
        //****************************************************
        public double Price
        {
            get
            {
                return price;
            }

            set
            {
                price = value;
            }
        }
        #endregion

        //****************************************************
        // Method: ToString
        //
        // Purpose: To return a string that describes the properties
        // of an Author Object.
        //****************************************************
        public override string ToString()
        {
            string authorsList = null;

            foreach (Author a in authors)
            {
                authorsList += a + "\n";
            }

            return "\nTitle: " + title + "\n" + authorsList + "Price: " + "$" + price;
        }

        #endregion
    }
}
