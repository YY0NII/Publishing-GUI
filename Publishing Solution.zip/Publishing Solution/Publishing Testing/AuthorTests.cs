﻿//******************************************************
// File: AuthorTests.cs
//
// Purpose: To test the properties, and methods for the 
// Author class.
// 
// Written By: Jonathon Carrera
//
// Compiler: Visual Studio 2019
//
//******************************************************

using Microsoft.VisualStudio.TestTools.UnitTesting;
using Publishing_Solution;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace Publishing_Testing
{
    [TestClass]
    public class AuthorTests
    {
        #region Author Test Methods
        //****************************************************
        // Method: TestFirst
        //
        // Purpose: To Test if the First function from the Author
        // Class is getting and setting the correct value.
        //****************************************************
        [TestMethod]
        public void TestFirst()
        {
            //Arrange: Variables required for test
            string expected = "Kevin";
            bool ignoreCase = false;
            Author a = new Author();

            //Act: Using the method to be tested
            a.First = expected;

            //Assert: Checking to see if it worked
            string actual = a.First;

            //****************************************************
            // Assert.AreEqual checks to see if the strings contained 
            // in expected & actual are equal. ignoreCase is a boolean
            // to make sure Casing is not ignored. If expected and actual
            // are equal there will be no error message when testing
            //****************************************************  
            Assert.AreEqual(expected, actual, ignoreCase, "First name not set correctly");

        }

        //****************************************************
        // Method: TestLast
        //
        // Purpose: To Test if the Last function from the Author
        // Class is getting and setting the correct value.
        //****************************************************
        [TestMethod]
        public void TestLast()
        {
            //Arrange
            string expected = "Carrera";
            bool ignoreCase = false;
            Author a = new Author();

            //Act
            a.Last = expected;

            //Assert
            string actual = a.Last;
            Assert.AreEqual(expected, actual, ignoreCase, "Last name not set correctly");
        }

        //****************************************************
        // Method: TestBackground
        //
        // Purpose: To Test if the Background function from the Author
        // Class is getting and setting the correct value.
        //****************************************************
        [TestMethod]
        public void TestBackground()
        {
            //Arrange
            string expected = "Older brother of Jonathon Carrera and avid gamer";
            bool ignoreCase = false;
            Author a = new Author();

            //Act
            a.Background = expected;

            //Assert
            string actual = a.Background;
            Assert.AreEqual(expected, actual, ignoreCase, "Background not set correctly");
        }
        #endregion
    }
}
