﻿//******************************************************
// File: BookTests.cs
//
// Purpose: To test the properties, and methods for the 
// Book class.
// 
// Written By: Jonathon Carrera
//
// Compiler: Visual Studio 2019
//
//******************************************************

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Publishing_Solution;

namespace Publishing_Testing
{
    [TestClass]
    public class BookTests
    {
        #region Book Test Methods
        //****************************************************
        // Method: TestTitle
        //
        // Purpose: To Test if the Title function from the Book
        // Class is getting and setting the correct value.
        //****************************************************
        [TestMethod]
        public void TestTitle()
        {
            //Arrange
            string expected = "Play Valorant Like the Pros";
            bool ignoreCase = false;
            Book b = new Book();

            //Act
            b.Title = expected;

            //Assert
            string actual = b.Title;
            Assert.AreEqual(expected, actual, ignoreCase, "Title not set correctly");
        }

        //****************************************************
        // Method: TestAuthor
        //
        // Purpose: To Test if the Author function from the Book
        // Class is getting and setting the correct value.
        //****************************************************
        [TestMethod]
        public void TestAuthor()
        {
            //Arrange
            Book b = new Book();
            List<Author> expected = new List<Author>();

            Author a = new Author();
            Author a2 = new Author();
            a.First = "David";

            expected.Add(a);
            expected.Add(a2);



            //Act
            b.Authors = expected;

            //Assert
            List<Author> actual = b.Authors;
            Assert.AreEqual(expected, actual, "Author not set correctly");
        }


        //****************************************************
        // Method: TestPrice
        //
        // Purpose: To Test if the Price function from the Book
        // Class is getting and setting the correct value.
        //****************************************************
        [TestMethod]
        public void TestPrice()
        {
            //Arrange
            double expected = 20.00;
            Book b = new Book();

            //Act
            b.Price = expected;

            //Assert
            double actual = b.Price;
            Assert.AreEqual(expected, actual, .001, "Price not set correctly");
        }
        #endregion
    }
}
