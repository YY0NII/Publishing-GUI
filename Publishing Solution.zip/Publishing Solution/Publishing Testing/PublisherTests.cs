﻿//******************************************************
// File: PublisherTests.cs
//
// Purpose: To test the FindBook method of the Publisher
// class.
// 
// Written By: Jonathon Carrera
//
// Compiler: Visual Studio 2019
//
//******************************************************
using System;
using System.IO;
using System.Runtime.Serialization.Json;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Publishing_Solution;

namespace Publishing_Testing
{
    [TestClass]
    public class PublisherTests
    {
        #region Publisher Test Methods
        //****************************************************
        // Method: TestFindBookWithGoodId
        //
        // Purpose: To Test that the FindBook method returns 
        // a book instance with the target title when given
        // a valid title
        //****************************************************
        [TestMethod]
        public void TestFindBookWithGoodId()
        {
            //Arranged
            Publisher p; // Don't need to call new here change to Publisher P;
            Book expected;

            string filename = "wrox.json";
            FileStream reader = new FileStream(filename, FileMode.Open, FileAccess.Read);

            DataContractJsonSerializer inputSerializer;
            inputSerializer = new DataContractJsonSerializer(typeof(Publisher));

            p = (Publisher)inputSerializer.ReadObject(reader); // ReadObject creates new instance of object
            reader.Dispose();

            //Act
            expected = p.Books[0];

            //Assert
            Book actual = p.FindBook(expected.Title);
            Assert.AreEqual(expected, actual, "Findbook not returning correct book");
        }

        //****************************************************
        // Method: TestFindBookWithBadId
        //
        // Purpose: To Test that the FindBook method returns 
        // null when given an invalid title 
        //****************************************************
        [TestMethod]
        public void TestFindBookWithBadId()
        {
            //Arranged
            Publisher p;

            string filename = "wrox.json";
            FileStream reader = new FileStream(filename, FileMode.Open, FileAccess.Read);

            DataContractJsonSerializer inputSerializer;
            inputSerializer = new DataContractJsonSerializer(typeof(Publisher));

            //Act
            p = (Publisher)inputSerializer.ReadObject(reader);
            reader.Dispose();

            //Assert
            Book actual = p.FindBook("Should not exist");
            Assert.AreEqual(null, actual, "Findbook not returning correct book");
        }
        #endregion
    }
}
