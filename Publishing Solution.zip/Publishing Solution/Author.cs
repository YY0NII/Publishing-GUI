﻿//******************************************************
// File: Author.cs
//
// Purpose: Contains member variables, properties, and 
// methods for the Author class
// 
// Written By: Jonathon Carrera
//
// Compiler: Visual Studio 2019
//
//****************************************************** 

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Publishing_Solution
{

    [DataContract]
    public class Author
    {
        #region Author Member Variables
        private string first;
        private string last;
        private string background;
        #endregion

        #region Author Methods
        //****************************************************
        // Method: Author()
        //
        // Purpose: To construct a default Author Object.
        //**************************************************** 
        public Author()
        {
            first = "John";
            last = "Doe";
            background = "unknown";
        }

        #region Author Properties
        [DataMember(Name = "first")]
        //****************************************************
        // Method: First
        //
        // Purpose: To return or set the value representing the
        // the Authors first name.
        //**************************************************** 
        public string First
        {
            get
            {
                return first;
            }

            set
            {
                first = value;
            }
        }

        [DataMember(Name = "last")]
        //****************************************************
        // Method: Last
        //
        // Purpose: To return or set the value representing the
        // the Authors last name.
        //****************************************************
        public string Last
        {
            get
            {
                return last;
            }

            set
            {
                last = value;
            }
        }

        [DataMember(Name = "background")]
        //****************************************************
        // Method: Background
        //
        // Purpose: To return or set the value representing the
        // the Authors Background.
        //****************************************************
        public string Background
        {
            get
            {
                return background;
            }

            set
            {
                background = value;
            }
        }
        #endregion

        //****************************************************
        // Method: ToString
        //
        // Purpose: To return a string that describes the properties
        // of an Author Object.
        //****************************************************
        public override string ToString()
        {
            return "Author: " + first + " " + last + "\nBackground: " + background;
        }

        #endregion
    }
}
